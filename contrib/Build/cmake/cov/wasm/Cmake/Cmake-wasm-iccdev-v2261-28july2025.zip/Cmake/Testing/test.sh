echo "cd $@"
cd $@
echo pwd
pwd
echo "ls -l"
ls -l
echo "./CreateAllProfiles.sh"
./CreateAllProfiles.sh
echo "./RunTests.sh"
./RunTests.sh
